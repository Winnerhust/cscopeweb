(function($) {
    var pattern = /^[a-zA-Z_0-9]{2,50}$/mg;

    //点击code以外的地方时隐藏悬浮提示
    $(document).on('click', function(e) {
        if ($('.mycode').css('display') == "none") //reason为弹出框的className，为减少客服端压力，如果原来就是隐藏的直接返回  
            return;
        var e = e || window.event; //浏览器兼容性 ，IE为window.event  
        var elem = e.target || e.srcElement; //IE为e.srcElement  

        while (elem) { //循环判断至跟节点，防止点击的是div子元素   
            if (elem.className && elem.className == 'mycode') {
                return;
            }
            elem = elem.parentNode;
        }
        $('.mycode').css('display', 'none'); //点击的不是div或其子元素   
    });

    //双击函数名称，变量名等时显示悬浮提示
    $(document).mouseup(function(e) {
        var text = encodeURIComponent(window.getSelection());
        text = text.replace(/\s/mg, "");
        if (!pattern.test(text)) {
            return;
        }
        var e = e || window.event; //浏览器兼容性 ，IE为window.event  
        var elem = e.target || e.srcElement; //IE为e.srcElement  

        while (elem) { //循环判断至跟节点，防止点击的是div子元素   
            if (elem.className && elem.className == 'mycode') {
                return;
            }
            elem = elem.parentNode;
        }

        //高亮关键字
        var doc = document.getElementsByTagName("body")[0]
        var fen = doc.innerHTML.split(text)
        doc.innerHTML = fen.join('<span class="fuck" style="background:#cfc;">' + text + '</span> ');
        //代码提示
        var oReq = new XMLHttpRequest();
        oReq.responseType = "document";
        oReq.onload = function() {
            var found = oReq.responseXML.querySelector('#symbol_found');
            if (found == null || found["value"] != "success") {
                return;
            }
            var result = oReq.responseXML.querySelector('div');

            if (result == null) {
                return;
            }
            var mycode = $('.mycode');

            if (mycode.length != 0) {
                $('.mycode').innerHTML = result.innerHTML
            } else {
                $('body').append(result)
            }

            // 插入新代码后重新渲染
            $('pre code').each(function(i, block) {
                hljs.highlightBlock(block);
            });

            // 调整提示框显示的位置
            var xOffset = -20;
            var yOffset = -10;

            $(".mycode").css("display", "block")
                .css("position", "absolute")
                .css("top", (e.pageY - xOffset) + "px")
                .css("left", (e.pageX + yOffset) + "px")
                .css("height", "100%")
                .css("width", "800px")
                .css("text-align", "left");
            // .css("background-color", "#ccc")

            if (result)
                console.log(result.innerHTML);
            else
                console.log('not found');
        };
        oReq.open("get", 'http://127.0.0.1:8080/symbol?symbol= ' + text);
        oReq.send();
    });


})(jQuery);