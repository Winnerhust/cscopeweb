package controllers

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strconv"

	"strings"

	"github.com/astaxie/beego"
)

type SymbolController struct {
	beego.Controller
}

func ReadLineN(filename string, lineno int, num int) string {
	f, err := os.Open(filename)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	lineend := lineno + num
	index := 0
	rd := bufio.NewReader(f)

	output := ""
	for {
		line, err := rd.ReadString('\n') //以'\n'为结束符读入一行

		if err != nil || io.EOF == err {
			break
		}
		index++
		if index >= lineno && index <= lineend {
			fmt.Println(line)
			output += line
		}
	}

	return output
}

// @router /symbol [get]
func (c *SymbolController) Get() {
	var dbPath = "/Users/chenxueyou/Downloads/inifile2-master/cscope.out"
	var ProjectPath = "/Users/chenxueyou/Downloads/inifile2-master"
	symbol := c.GetString("symbol", "")

	beego.Info("symbol:", symbol)

	var strCmd = fmt.Sprintf("cscope -f %s -d -L -1 %s",
		dbPath,
		symbol)
	beego.Info("cscope", strCmd)
	cmd := exec.Command("sh", "-c", strCmd)
	out, err := cmd.CombinedOutput()
	if err != nil {
		fmt.Println(err)
	}

	SymbolDefine := string(out)
	beego.Info(SymbolDefine)

	SymbolFound := "not found"
	if len(SymbolDefine) != 0 {
		SymbolFound = "success"

		list := strings.Split(SymbolDefine, " ")
		file := ProjectPath + "/" + list[0]
		lineno, _ := strconv.Atoi(list[2])

		num := 10
		SymbolDefine = ReadLineN(file, lineno, num)
	}
	c.Data["SymbolFound"] = SymbolFound
	c.Data["SymbolDefine"] = SymbolDefine
	c.TplName = "symbol_define.html"
}
