package main

import (
	_ "cscopeweb/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

