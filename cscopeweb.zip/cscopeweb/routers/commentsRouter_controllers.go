package routers

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context/param"
)

func init() {

	beego.GlobalControllerRouter["cscopeweb/controllers:SymbolController"] = append(beego.GlobalControllerRouter["cscopeweb/controllers:SymbolController"],
		beego.ControllerComments{
			Method: "Get",
			Router: `/symbol`,
			AllowHTTPMethods: []string{"get"},
			MethodParams: param.Make(),
			Params: nil})

}
